/*Pattern48
4 4 4 4 4 4 4 
  3 3 3 3 3
    2 2 2 
      1
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	int num=size;
	for(int out=1;out<=size;out++){
		for(int space=2;space<=out;space++)
			printf("  ");
		for(int in=size*2-1;in>=(out*2)-1;in--){
			printf("%d ",num);
		}
		num--;
		printf("\n");
	}
}
