/*
 Pattern57
D
D C
D C B
D C B A
D C B
D C
D */
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=1;i<=size;i++){
		char ch = 64+(size+1)/2;
		for(int j=1;j<=(size+1)/(2);j++){
			if((i-j >= 0 && i <= (size+1)/(2))|| (i+j <= (size+1) && i>= (size+3)/(2))) 
				printf("%c ",ch--);
			else
				printf(" ");
		}
		printf("\n");
	}
}
