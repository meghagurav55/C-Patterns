/*
      Pattern84
          A
         B B
        C   C
       D     D
      E       E
       */
#include <stdio.h>
void main(){
	char ch=65;
	for(int i=0;i<5;i++){
		for(int j=0;j<9;j++){
			if((i+j == 4 && j < 5) || (j-i == 4 && j >= 5))		
				printf("%c ",ch);
			else
				printf("  ");
		}
		ch++;
		printf("\n");
	}
}


