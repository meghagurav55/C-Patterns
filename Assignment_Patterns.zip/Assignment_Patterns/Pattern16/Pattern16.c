/*
Pattern16
1 1 1 1 1
2 2 2 2
3 3 3
4 4
5<
*
*/
#include <stdio.h>
void main(){
	
	int size;
	
	printf("Enter the size : ");
	scanf("%d",&size);
	int num=1;
	for(int i=size;i>=1;i--){
		for(int j=1;j<=i;j++)
			printf("%d\t",num);
		printf("\n");
		num++;
	}


}
