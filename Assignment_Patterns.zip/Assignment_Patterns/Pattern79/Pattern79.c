/*Pattern79
      A
     B B
    C C C
   D D D D
  E E E E E
   D D D D
    C C C
     B B
      A
       */
#include <stdio.h>
void main(){
	char ch=65;
	for(int i=0;i<=8;i++){
		if(i <= 4){
			for(int space=i;space<=4;space++){
				printf(" ");
			}
			for(int j=0;j<=i;j++){
				printf("%c ",ch);
			}
			printf("\n");
		}else{
		

			for(int space=i+1;space>=5;space--){
				printf(" ");
			}
			for(int j=0;j<=8-i;j++){
				printf("%c ",ch);
			}
			printf("\n");
		}
		ch++;
	}
}


