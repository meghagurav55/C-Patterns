/*PPattern97

  *                 *
  * *             * * 
  * * *         * * * 
  * * * *     * * * *
  * * * * * * * * * *
                  */
#include <stdio.h>
void main(){
	for(int i=0;i<5;i++){
		for(int j=0;j<10;j++){
			if((i-j >= 0 || i+j >= 9))
				printf("* ");
			else
				printf("  ");
		}
		printf("\n");
	}
}
