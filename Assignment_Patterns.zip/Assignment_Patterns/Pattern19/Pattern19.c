/*Pattern19
A B C D E
A B C D
A B C
A B
A
*/
#include <stdio.h>
void main(){
	
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=size;i>=1;i--){
		char ch='A';	
		for(int j=1;j<=i;j++)
			printf("%c\t",ch++);
		printf("\n");
	}


}
