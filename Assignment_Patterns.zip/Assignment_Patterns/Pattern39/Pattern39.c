/*
Pattern39
        1
      1 2 3
    1 2 3 4 5 
  1 2 3 4 5 6 7
1 2 3 4 5 6 7 8 9*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int out=1;out<=size;out++){
		for(int space=size-1;space>=out;space--){
			printf("\t");
		}
		for(int in=1;in<=(out*2)-1;in++){
			printf("%d\t",in);
		}
		printf("\n");
	}
}
