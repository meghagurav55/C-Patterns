/*
Pattern90

      E       E
       D     D
        C   C
         B B
          A

       */
#include <stdio.h>
void main(){
	char c=69;
	for(int i=0;i<5;i++){
		for(int j=0;j<9;j++){
			if((i-j == 0 && j < 5) || (i+j == 8 && j >= 5))		
				printf("%c ",c);
			else
				printf("  ");
		}
		c--;
		printf("\n");
	}
}


