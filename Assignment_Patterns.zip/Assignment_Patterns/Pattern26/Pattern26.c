//two for loops
/*Pattern26
        1
      1 2
    1 2 3
  1 2 3 4
1 2 3 4 5*/
#include <stdio.h>
void main(){
	int size, num=1;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int outer=0;outer<size;outer++){
		num = 1;
		for(int inner=0;inner<size;inner++){
			if(inner+outer >= size-1)
				printf("%d ",num++);
			else
				printf("  ");
		}
		printf("\n");

	}
}
