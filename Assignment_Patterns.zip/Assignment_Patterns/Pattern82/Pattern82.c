/*
Pattern82
          1
         2 2
        3   3
       4     4
      5       5
      *       *
       */
#include <stdio.h>
void main(){
	int num=1;
	for(int i=0;i<5;i++){
		for(int j=0;j<9;j++){
			if((i+j == 4 && j < 5) || (j-i == 4 && j >= 5))		
				printf("%d ",num);
			else
				printf("  ");
		}
		num++;
		printf("\n");
	}
}


