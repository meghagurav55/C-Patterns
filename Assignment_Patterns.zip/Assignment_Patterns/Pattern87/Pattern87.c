/*
     Pattern87

      1       1
       2     2
        3   3
         4 4
          5 

       */
#include <stdio.h>
void main(){
	for(int i=0;i<5;i++){
		for(int j=0;j<9;j++){
			if((i-j == 0 && j < 5) || (i+j == 8 && j >= 5))		
				printf("%d ",i+1);
			else
				printf("  ");
		}
		printf("\n");
	}
}


