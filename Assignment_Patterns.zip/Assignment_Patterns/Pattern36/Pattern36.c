/*
 * Pattern36
        1
      3 3 3 
    5 5 5 5 5 
  7 7 7 7 7 7 7
9 9 9 9 9 9 9 9 9 
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	int num=1;
	for(int out=1;out<=size;out++){
		for(int space=size-1;space>=out;space--){
			printf("\t");
		}
		for(int in=1;in<=(out*2)-1;in++){
			printf("%d\t",num);
		}
		num += 2;
		printf("\n");
	}
}
