/*Pattern70
 5 5 5 5 5
  4 4 4 4
   3 3 3
    2 2
     1 */
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	int no=size;
	for(int i=0;i<size;i++){
		for(int space=1;space<=i;space++){
			printf(" ");
		}
		for(int j=size;j>i;j--){
			printf("%d ",no);
		}
		no--;
		printf("\n");
	}
}
