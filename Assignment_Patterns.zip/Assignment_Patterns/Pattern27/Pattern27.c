/*
 Pattern27
         A
       B B
     C C C 
   D D D D
 E E E E E*/
#include <stdio.h>
void main(){
	int size, ch=65;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int outer=0;outer<size;outer++){
		for(int inner=0;inner<size;inner++){
			if(inner+outer >= size-1)
				printf("%c ",ch);
			else
				printf("  ");
		}
		ch++;
		printf("\n");
	}
}
