/*Pattern91,
           *
          * *
         *   *
        *     *
       *       *
        *     *
         *   *
          * *
           *
*/
#include <stdio.h>
void main(){
	for(int i=0;i<9;i++){
		for(int j=0;j<9;j++){
			if(((i+j == 4  || j-i ==4) && (j<=4 || i<=4)) || ((i-j == 4 || i+j == 12) && (j>=5 || i >= 5)))
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
	}
}
