/*Pattern48
Pattern49
7 7 7 7 7 7 7
  5 5 5 5 5
    3 3 3 
      1
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	int num=size*2-1;
	for(int out=1;out<=size;out++){
		for(int space=2;space<=out;space++)
			printf("  ");
		for(int in=size*2-1;in>=(out*2)-1;in--){
			printf("%d ",num);
		}
		num = num - 2;
		printf("\n");
	}
}
