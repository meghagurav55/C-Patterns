/*Pattern71
 5 4 3 2 1
  4 3 2 1
   3 2 1
    2 1
     1
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	int num=size;
	for(int i=0;i<size;i++){
		int no=num;
		for(int space=1;space<=i;space++){
			printf(" ");
		}
		for(int j=size;j>i;j--){
			printf("%d ",no--);
		}
		num = num - 1;
		printf("\n");
	}
}
