/*Pattern92
           1
          2 2
         3   3
        4     4
       5       5
        4     4
         3   3
          2 2
           1
*/
#include <stdio.h>
void main(){
	int num1=1;
	int num2=9;
	for(int i=0;i<9;i++){
		for(int j=0;j<9;j++){
			if(((i+j == 4  || j-i ==4) && (j<=4 || i<=4))) 
				printf("%d ",num1);
			else if((i-j == 4 || i+j == 12 ) && (j>=5 || i>=5))
				printf("%d ",num2);
			else
				printf("  ");
		}
		num1++;
		num2--;
		printf("\n");
	}
}
