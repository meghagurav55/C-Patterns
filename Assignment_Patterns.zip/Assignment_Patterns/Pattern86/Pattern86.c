/*
Pattern86

      *       *
       *     *
        *   *
         * *
          *

       */
#include <stdio.h>
void main(){
	for(int i=0;i<5;i++){
		for(int j=0;j<9;j++){
			if((i-j == 0 && j < 5) || (i+j == 8 && j >= 5))		
				printf("* ");
			else
				printf("  ");
		}
		printf("\n");
	}
}


