/*
Pattern45
      1
    1 2 1
  1 2 3 2 1
1 2 3 4 3 2 1
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int out=1;out<=size;out++){
		for(int space=size-1;space>=out;space--){
			printf("\t");
		}
			
		int n=1;
		for(int in=1;in<=(out*2)-1;in++){
			if(out<=in)
				printf("%d\t",n--);
			else
				printf("%d\t",n++);
		}
		printf("\n");
	}
}
