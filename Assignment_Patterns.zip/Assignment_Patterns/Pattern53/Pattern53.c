/*
 Pattern53
A B C D E F G
  A B C D E
    A B C 
      A */

#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int out=1;out<=size;out++){
		for(int space=2;space<=out;space++){
			printf("  ");
		}
		char ch = 65;
		for(int in=(size*2)-1;in>=(out*2)-1;in--)
			printf("%c ",ch++);
		printf("\n");
	}
}
