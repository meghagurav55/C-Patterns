/*
Pattern95
           E
          D D
         C   C
        B     B
       A       A
        B     B
         C   C
          D D
           E

*/
#include <stdio.h>
void main(){
	char c1=69;
	char c2=61;
	for(int i=0;i<9;i++){
		for(int j=0;j<9;j++){
			if(((i+j == 4  || j-i ==4) && (j<=4 || i<=4))) 
				printf("%c ",c1);
			else if((i-j == 4 || i+j == 12 ) && (j>=5 || i>=5))
				printf("%c ",c2);
			else
				printf("  ");
		}
		c1--;
		c2++;
		printf("\n");
	}
}
