/*Pattern80
      A
     A B
    A B C
   A B C D
  A B C D E
   B C D E
    C D E
     D E
      E

       */
#include <stdio.h>
void main(){
	char c1 = 65;
	for(int i=0;i<=8;i++){
		if(i <= 4){
			char ch = 65;
			for(int space=i;space<=4;space++){
				printf(" ");
			}
			for(int j=0;j<=i;j++){
				printf("%c ",ch++);
			}
			printf("\n");
		}else{
			char c = c1 + 1;
			for(int space=i+1;space>=5;space--){
				printf(" ");
			}
			for(int j=0;j<=8-i;j++){
				printf("%c ",c++);
			}
			printf("\n");
			c1++;
		}
	}
}


