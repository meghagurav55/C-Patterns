/*Pattern62
        D
      C D
    B C D
  A B C D
    B C D
      C D
        D
*/
#include <stdio.h>
void main(){
	int size=0;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=0;i<size;i++){
		char ch='A';
		for(int j=0;j<((size)/2)+1;j++){
			if(i+j >= size/2 && i-j <= size/2)
				printf("%c ",ch++);
			else
				printf("  ");
		}
		printf("\n");
	}
}
