/*
 Pattern33
A B C D E
  A B C D
    A B C 
      A B
        A*/

#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int out=0;out<size;out++){
		for(int space=0;space<out;space++)
			printf("  ");
		char ch = 65;
		for(int in=size;in>out;in--)
			printf("%c ",ch++);
		printf("\n");
	}
}
