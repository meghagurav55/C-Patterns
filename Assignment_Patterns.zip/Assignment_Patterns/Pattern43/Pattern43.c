/*
Pattern43
        0
      1 0 1
    2 1 0 1 2
  3 2 1 0 1 2 3
4 3 2 1 0 1 2 3 4
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	int n=0;
	for(int out=1;out<=size;out++){
		for(int space=size-1;space>=out;space--){
			printf("\t");
		}
			
		for(int in=1;in<=(out*2)-1;in++){
			if(out<=in)
				printf("%d\t",n++);
			else
				printf("%d\t",n--);
		}
		printf("\n");
	}
}
