/*
Pattern61
        3
      2 3
    1 2 3 
  0 1 2 3 
    1 2 3
      2 3
        3*/
#include <stdio.h>
void main(){
	int size=1;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=0;i<size;i++){
		int num=(size)/(2);
		for(int j=0;j<(size+1)/(2);j++){
			if(i+j >= size/(2) && i-j <= (size)/(2))
				printf("%d ",num--);
			else
				printf("  ");
		}
		printf("\n");

	}
}
