/*Pattern68
     A
    A B
   A B C
  A B C D
 A B C D E
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	int no=size;
	for(int i=1;i<=size;i++){
		char c=65;
		for(int space=1;space<no;space++){
			printf(" ");
		}
		no--;
		for(int j=1;j<=i;j++){
			printf("%c ",c++);
		}
		printf("\n");
	}
}
