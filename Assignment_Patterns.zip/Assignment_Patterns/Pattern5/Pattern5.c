/*
 Pattern5
A B C D E
A B C D E 
A B C D E
A B C D E
A B C D E*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=1;i<=size;i++){
		char ch = 'A';
		for(int j=1;j<=size;j++){
			printf("%c\t",ch++);
		}
		printf("\n");
	}
}
