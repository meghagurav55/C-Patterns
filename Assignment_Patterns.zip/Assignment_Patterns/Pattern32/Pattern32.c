/*
 *
Pattern32
E E E E E
  D D D D
    C C C
      B B
        A
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the number : ");
	scanf("%d",&size);
	int ch = 64+size;
	for(int out=0;out<size;out++){
		for(int space=0;space<out;space++){
			printf("  ");
		}
		for(int in=size;in>out;in--)
			printf("%c ",ch);
		ch--;
		printf("\n");
	}
}
