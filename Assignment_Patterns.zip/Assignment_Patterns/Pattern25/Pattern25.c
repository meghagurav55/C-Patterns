/*Pattern25
        1
      2 2
    3 3 3
  4 4 4 4
5 5 5 5 5*/
#include <stdio.h>
void main(){
	
	int size;
	
	printf("Enter the size : ");
	scanf("%d",&size);

	for(int outer=1;outer<=size;outer++){
		for(int space=size-1;space>=outer;space--){
			printf("  ");
		}
		for(int inner=1;inner<=outer;inner++){
			printf("%d ",outer);
		}
		printf("\n");
	}
}
