/*Pattern94
           A
          B B
         C   C
        D     D
       E       E
        D     D
         C   C
          B B
           A

*/
#include <stdio.h>
void main(){
	char c1=65;
	char c2=73;
	for(int i=0;i<9;i++){
		for(int j=0;j<9;j++){
			if(((i+j == 4  || j-i ==4) && (j<=4 || i<=4))) 
				printf("%c ",c1);
			else if((i-j == 4 || i+j == 12 ) && (j>=5 || i>=5))
				printf("%c ",c2);
			else
				printf("  ");
		}
		c1++;
		c2--;
		printf("\n");
	}
}
