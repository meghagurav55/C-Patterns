/*
 * * * * * *
 * * * * * *
 * * * * * *
 * * * * * *
 * * * * * *
 */
#include <stdio.h>
void main(){
	int size;
	
	printf("Enter the size : ");
	scanf("%d",&size);

	for(int i=1;i<=size*size;i++){
		if(i % size == 0)
			printf("*\n");
		else
			printf("*   ");
	}
}
