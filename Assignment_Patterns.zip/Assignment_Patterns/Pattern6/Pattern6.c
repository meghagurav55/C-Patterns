/*
 Pattern6
5 5 5 5 5
4 4 4 4 4
3 3 3 3 3
2 2 2 2 2 
1 1 1 1 1
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=size;i>=1;i--){
		for(int j=1;j<=size;j++){
			printf("%d\t",i);
		}
		printf("\n");
	}
}
