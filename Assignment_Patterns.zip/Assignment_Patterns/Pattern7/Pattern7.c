/*
5 4 3 2 1
5 4 3 2 1
5 4 3 2 1 
5 4 3 2 1
5 4 3 2 1
 */
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=1;i<=size;i++){
		for(int j=size;j>=1;j--){
			printf("%d\t",j);
		}
		printf("\n");
	}
}
