/*
 
Pattern37
        A
      B B B
    C C C C C
  D D D D D D D
E E E E E E E E E
*/
#include <stdio.h>
void main(){
	int size;
	char ch='A';
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int out=1;out<=size;out++){
		for(int space=size;space>=out;space--)
			printf("  ");
		for(int in=1;in<=(out*2)-1;in++){
			printf("%c ",ch);
		}
		ch++;
		printf("\n");
	}
}
