/*
Pattern72
 E E E E E
  D D D D
   C C C
    B B
     A*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	char ch=64+size;
	for(int i=0;i<size;i++){
		for(int space=1;space<=i;space++){
			printf(" ");
		}
		for(int j=size;j>i;j--)
			printf("%c ",ch);
		ch--;
		printf("\n");
	}
}
