/*
Pattern41
        A
      A B C 
    A B C D E 
  A B C D E F G
A B C D E F G H I

*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int out=1;out<=size;out++){
		char ch=65;
		for(int space=size-1;space>=out;space--){
			printf("\t");
		}
			
		for(int in=1;in<=(out*2)-1;in++){
			printf("%c\t",ch++);
		}
		printf("\n");
	}
}
