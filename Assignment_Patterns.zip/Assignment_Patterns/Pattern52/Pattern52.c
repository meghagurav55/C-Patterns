/*Pattern52
G G G G G G G
  E E E E E
    C C C 
      A*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the szie : ");
	scanf("%d",&size);
	char ch =(size * 2) - 2  + 65;
	for(int out=1;out<=size;out++){
		for(int space=2;space<=out;space++){
			printf("   ");
		}
		for(int in=(size*2)-1;in>=(out*2)-1;in--){
			printf("%c  ",ch);
		}
		printf("\n");
		ch -= 2;
	}
}
