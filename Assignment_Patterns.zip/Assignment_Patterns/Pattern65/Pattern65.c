/*
Pattern65
     1
    2 2
   3 3 3
  4 4 4 4
 5 5 5 5 5*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=0;i<size;i++){
		for(int j=size;j>=0;j--){
			if(i-j >= 0)
				printf(" %d",i+1);
			else
				printf(" ");
		}
		printf("\n");
	}
}
