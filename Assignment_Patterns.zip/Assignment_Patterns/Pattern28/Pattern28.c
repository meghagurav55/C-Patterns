/*
with 3 for loops
 Pattern28
         A 
       A B
     A B C
   A B C D
 A B C D E*/

#include <stdio.h>
void main(){
	int size, ch=65;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int outer=0;outer<size;outer++){
		for(int space=size-1;space>outer;space--){
			printf("  ");
		}
		ch = 65;
		for(int inner=0;inner<=outer;inner++){
			printf("%c ",ch++);
		}
		printf("\n");
	}
}
