/*Pattern18
A A A A A
B B B B
C C C 
D D 
E 
*/
#include <stdio.h>
void main(){
	
	int size;
	char ch='A';	
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=size;i>=1;i--){
		for(int j=1;j<=i;j++)
			printf("%c\t",ch);
		printf("\n");
		ch++;
	}


}
