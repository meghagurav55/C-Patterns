#include <stdio.h>
void main(){
	char ch = 'D';
	for(int i=1;i<=7;i++){
		for(int j=1;j<=4 && i+j <= 8 && i-j>=0;j++){
			if(i-j == 0 || i+j == 8)
				printf("D ");
			else if(i-j == 1 || i+j == 7)
				printf("C ");
			else if(i-j == 2 || i+j == 6)
				printf("B ");
			else if(i-j == 3 || i+j == 5)
				printf("A ");
			else
				printf("  ");
			ch++;
		}
		printf("\n");
	}
}
