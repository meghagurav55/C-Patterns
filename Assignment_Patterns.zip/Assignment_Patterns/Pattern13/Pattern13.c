/*Pattern13
A
B B 
C C C
D D D D
E E E E E
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(char i=65;i<=64+size;i++){
		for(int j=65;j<=i;j++)
			printf("%c  ",i);
		printf("\n");
	}

}
