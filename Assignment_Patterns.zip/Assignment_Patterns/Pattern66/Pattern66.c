/*Pattern66
     1
    1 2 
   1 2 3 
  1 2 3 4
 1 2 3 4 5*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	int no=size-1;
	for(int i=1;i<=size;i++){
		int num=1;
		for(int space=1;space<=no;space++){
			printf(" ");
		}	
		no--;
		for(int j=1;j<=i;j++)
			printf(" %d",num++);
		printf("\n");
	}
}
