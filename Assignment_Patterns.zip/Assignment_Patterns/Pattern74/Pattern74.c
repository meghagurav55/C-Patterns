/*
Pattern74
 A B C D E
  A B C D
   A B C 
    A B 
     A
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=0;i<size;i++){
		char ch = 65;
		for(int space=1;space<=i;space++){
			printf(" ");
		}	
		for(int j=size;j>i;j--)
			printf("%c ",ch++);
		printf("\n");
	}

}
