/*
Pattern22
E E E E E
D D D D
C C C
B B 
A
*/
#include <stdio.h>
void main(){
	
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=64+size;i>=65;i--){
		for(int j=65;j<=i;j++)
			printf("%c \t",i);
		printf("\n");
	}


}
