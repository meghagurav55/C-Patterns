/*
 Pattern40
        1
      3 2 1
    5 4 3 2 1
  7 6 5 4 3 2 1
9 8 7 6 5 4 3 2 1

*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	int num=1;
	for(int out=1;out<=size;out++){
		for(int space=size-1;space>=out;space--){
			printf("\t");
		}
			
		int no=num;
		for(int in=1;in<=(out*2)-1;in++){
			printf("%d\t",no--);
		}
		num = num + 2;
		printf("\n");
	}
}
