/*
Pattern38
        A
      C C C 
    E E E E E
  G G G G G G G
I I I I I I I I I 
*/
#include <stdio.h>
void main(){
	int size;
	char ch='A';
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int out=1;out<=size;out++){
		for(int space=size;space>=out;space--)
			printf("  ");
		for(int in=1;in<=(out*2)-1;in++){
			printf("%c ",ch);
		}
		ch+=2;
		printf("\n");
	}
}
