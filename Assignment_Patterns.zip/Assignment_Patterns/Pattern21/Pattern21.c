/*
Pattern21
5 4 3 2 1
5 4 3 2
5 4 3
5 4 
5 

*/
#include <stdio.h>
void main(){
	
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=size;i>=1;i--){
		int num=size;
		for(int j=1;j<=i;j++)
			printf("%d\t",num--);
		printf("\n");
	}


}
