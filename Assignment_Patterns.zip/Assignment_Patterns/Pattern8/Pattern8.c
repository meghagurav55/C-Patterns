/*
Pattern8
E E E E E
D D D D D
C C C C C
B B B B B
A A A A A*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(char c = 64+size;c>=65;c--){
		for(int inner=1;inner<=size;inner++){
			printf("%c\t",c);
		}
		printf("\n");

	}
}
