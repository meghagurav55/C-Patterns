/*
       Pattern83
          5
         4 4
        3   3
       2     2
      1       1
      *
       */
#include <stdio.h>
void main(){
	int num=5;
	for(int i=0;i<5;i++){
		for(int j=0;j<9;j++){
			if((i+j == 4 && j < 5) || (j-i == 4 && j >= 5))		
				printf("%d ",num);
			else
				printf("  ");
		}
		num--;
		printf("\n");
	}
}


