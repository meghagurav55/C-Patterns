/*Pattern55
3 
3 2 
3 2 1 
3 2 1 0
3 2 1 
3 2
3 */
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int out=1;out<=size;out++){
		int num=size/2;
		for(int in=1;in<=(size+1)/2;in++){
			if(((out-in >= 0) && (out <= (size/2)+1)) || ((in+out <= size+1) && (out > (size/2)+1)))
				printf("%d  ",num);
			else
				printf("   ");
			num--;
		}
		printf("\n");
	}
}
