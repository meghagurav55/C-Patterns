/*

Pattern46
        A
      A B A
    A B C A B
  A B C D A B C
A B C D E A B C D
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int out=1;out<=size;out++){
		for(int space=size-1;space>=out;space--){
			printf("\t");
		}
			
		char ch=65;
		for(int in=1;in<=(out*2)-1;in++){
			if(out<=in)
				printf("%c\t",ch--);
			else
				printf("%c\t",ch++);
		}
		printf("\n");
	}
}
