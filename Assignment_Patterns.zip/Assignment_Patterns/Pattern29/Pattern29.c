/*Pattern29
 * * * * *
   * * * *
     * * *
       * *
         *
*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int outer=0;outer<size;outer++){
		for(int space=0;space<outer;space++){
			printf("  ");
		}
		for(int inner=size;inner>outer;inner--){
			printf("* ");
		}
		printf("\n");
	}
}
