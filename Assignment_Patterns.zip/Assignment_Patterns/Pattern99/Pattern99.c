/*Pattern99

        *             *
      * * *         * * *
    * * * * *     * * * * *
  * * * * * * * * * * * * * *
*/
#include <stdio.h>
void main(){
	for(int i=0;i<4;i++){
		for(int j=0;j<14;j++){
			if(((i+j >= 3 && j<=3 ) || (j-i <= 3 && j<=6 && j > 3)) || ((i+j >= 10 && j >= 7 && j <= 10)) || (j-i<=10 && j>=11))
				printf("* ");
			else
				printf("  ");
		}
		printf("\n");
	}
}
