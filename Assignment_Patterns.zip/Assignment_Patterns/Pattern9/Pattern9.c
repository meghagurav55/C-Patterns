/*
Pattern9
E D C B A
E D C B A 
E D C B A
E D C B A
E D C B A*/

#include <stdio.h>
void main(){
	int size;
	printf("Ente size : ");
	scanf("%d",&size);
	for(int i=1;i<=size;i++){
		for(char j=64+size;j>=65;j--){
			printf(" %c\t",j);
		}
		printf("\n");
	}
}
