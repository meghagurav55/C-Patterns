/*Pattern63
        D
      D C
    D C B
  D C B A
    D C B
      D C
        D*/
#include <stdio.h>
void main(){
	int size=0;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=0;i<size;i++){
		char ch = (size/2) + 65;
		for(int j=0;j<(size/2)+1;j++){
			if(i+j >= size/2 && i-j <= size/2)
				printf("%c ",ch--);
			else
				printf("  ");
		}
		printf("\n");
	}
}
