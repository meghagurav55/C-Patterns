/*Pattern73
 E D C B A
  D C B A
   C B A 
    B A
     A*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	char ch=size+64;
	for(int i=0;i<size;i++){
		char c = ch;
		for(int space=1;space<=i;space++){
			printf(" ");
		}
		for(int j=size;j>i;j--)
			printf("%c ",c--);
		ch -= 1;
		printf("\n");
	}
}
