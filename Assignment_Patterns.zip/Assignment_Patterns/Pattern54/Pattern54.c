/*
 Pattern54
* 
* *
* * *
* * * *
* * *
* *
*
*/

#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int out=1;out<=size;out++){
		for(int in=1;in<=(size+1)/2;in++){
			if((out <= size/2+1 && (out-in) >= 0) || (out > size/2+1 && (in+out) <= size+1))
				printf("* ");
			else
				printf("  ");
		}
		printf("\n");
	}
}
