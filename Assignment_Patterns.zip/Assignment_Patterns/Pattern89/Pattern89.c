/*
Pattern89
      A       A
       B     B
        C   C
         D D
          E

       */
#include <stdio.h>
void main(){
	char c=65;
	for(int i=0;i<5;i++){
		for(int j=0;j<9;j++){
			if((i-j == 0 && j < 5) || (i+j == 8 && j >= 5))		
				printf("%c ",c);
			else
				printf("  ");
		}
		c++;
		printf("\n");
	}
}


