#include <stdio.h>
void main(){
	for(int i=0;i<4;i++){
		for(int space=3;space>=i;space--)
			printf(" ");
		for(int j=0;j<8;j++){
			if((j-i <= 4 && j >= 4) || (i-j>=0 && j<=3))
				printf("* ");
			else
				printf("  ");
		} 
		printf("\n");
	}

}
