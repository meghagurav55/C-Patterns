/*
 Pattern35
        1
      2 2 2 
    3 3 3 3 3
  4 4 4 4 4 4 4
5 5 5 5 5 5 5 5 5*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=1;i<=size;i++){
		for(int space=size-1;space>=i;space--){
			printf("  ");
		}
		for(int j=1;j<=(i*2)-1;j++){
			printf("%d ",i);
		}
		printf("\n");
	}
}
