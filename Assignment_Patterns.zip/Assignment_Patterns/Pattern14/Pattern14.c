/*
 Pattern14
A 
A B
A B C
A B C D
A B C D E
*/
#include <stdio.h>
void main(){
	
	int size;
	
	printf("Enter the size : ");
	scanf("%d",&size);

	for(int i=65;i<=64+size;i++){
		for(int j=65;j<=i;j++)
			printf("%c  ",j);
		printf("\n");
	}


}
