/*Pattern4
A A A A A
B B B B B
C C C C C
D D D D D
E E E E E
*/
#include <stdio.h>
void main(){
	int size;
	char ch='A';
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=1;i<=size;i++){
		for(int j=1;j<=size;j++){
			printf("%c\t",ch);	
		}
		ch++;
		printf("\n");	
	}
}
