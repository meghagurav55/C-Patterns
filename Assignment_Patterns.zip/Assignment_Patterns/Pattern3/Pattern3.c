/*1 2 3 4 5
  1 2 3 4 5
  1 2 3 4 5
  1 2 3 4 5
  1 2 3 4 5
  */
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=1;i<=size;i++){
		for(int j=1;j<=size;j++){
			printf("%d\t",j);
		}
		printf("\n");
	}
}
