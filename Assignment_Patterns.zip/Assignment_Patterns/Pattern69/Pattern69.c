/*Pattern69
 * * * * *
  * * * *
   * * *
    * *
     **/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int i=0;i<size;i++){
		for(int space=1;space<=i;space++){
			printf(" ");
		}
		for(int j=size;j>i;j--){
			printf("* ");
		}
		printf("\n");
	}
}
