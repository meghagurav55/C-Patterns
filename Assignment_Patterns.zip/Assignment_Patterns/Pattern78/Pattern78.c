/*
Pattern78
       1
      1 2
     1 2 3
    1 2 3 4
   1 2 3 4 5
    1 2 3 4
     1 2 3
      1 2
       1*/
#include <stdio.h>
void main(){
	for(int i=0;i<=8;i++){
		int num=1;	
		if(i <= 4){
			for(int space=i;space<=4;space++){
				printf(" ");
			}
			for(int j=0;j<=i;j++){
				printf("%d ",num++);
			}
			printf("\n");
		}else{
		

			for(int space=i+1;space>=5;space--){
				printf(" ");
			}
			for(int j=0;j<=8-i;j++){
				printf("%d ",num++);
			}
			printf("\n");
		}
	}
}


