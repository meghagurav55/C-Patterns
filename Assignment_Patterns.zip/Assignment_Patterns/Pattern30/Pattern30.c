/*
Pattern30
5 5 5 5 5
  4 4 4 4
    3 3 3
      2 2
        1*/
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	for(int outer=size;outer>0;outer--){
		for(int inner=size;inner>0;inner--){
			if(inner - outer <= 0)
				printf("%d  ",outer);
			else
				printf("   ");
		}
		printf("\n");
	}
}
