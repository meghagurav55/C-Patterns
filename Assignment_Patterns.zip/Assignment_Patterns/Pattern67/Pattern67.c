/*Pattern67
     A
    B B
   C C C
  D D D D
 E E E E E*/
#include <stdio.h>
void main(){
	int size;
	char ch='A';
	printf("Enter the size : ");
	scanf("%d",&size);
	int no=size;
	for(int i=1;i<=size;i++){
		for(int space=1;space<no;space++){
			printf(" ");
		}
		no--;
		for(int j=1;j<=i;j++){
			printf("%c ",ch);
		}
		ch++;
		printf("\n");
	}

}
