/*
 Pattern51
D D D D D D D
  C C C C C
    B B B 
      A */
#include <stdio.h>
void main(){
	int size;
	printf("Enter the size : ");
	scanf("%d",&size);
	char ch='A' + size - 1;
	for(int out=1;out<=size;out++){
		for(int space=2;space<=out;space++){
			printf("  ");
		}
		for(int in=(size*2)-1;in>=(out*2)-1;in--){
			printf("%c ",ch);
		}
		ch--;
		printf("\n");
	}
}
